import network
import utime
import ubinascii
import usocket
import machine

# Configure network credentials
ssid = 'ASUS_D0'
password = 'gamma_4355'

# Connect to the Wi-Fi network
wifi = network.WLAN(network.STA_IF)
wifi.active(True)
wifi.connect(ssid, password)

# Wait until the Wi-Fi connection is established
while not wifi.isconnected():
    utime.sleep(1)

# Print the network configuration details
print("Connected to Wi-Fi!")
print("Network Config:", wifi.ifconfig())
print("MAC Address:", ubinascii.hexlify(wifi.config("mac"), ":").decode())

# Create an instance of the temperature sensor
sensor_temp = machine.ADC(machine.ADC.CORE_TEMP)

# Convert the raw ADC reading to temperature in Celsius
conversion_factor = 3.3 / (65535)  # Conversion factor based on Vref and ADC resolution

# Connect to the server
SERVER_IP = '192.168.50.180'
SERVER_PORT = 5005
client_socket = usocket.socket(usocket.AF_INET, usocket.SOCK_STREAM)
server_address = (SERVER_IP, SERVER_PORT)
client_socket.connect(server_address)
print("Connected to Server")

while True:
# Get temperature and send it to the server
    raw_reading = sensor_temp.read_u16()
    temperature = (raw_reading * conversion_factor - 0.706) / 0.001721
    temperature_str = str(temperature)
    client_socket.sendall(temperature_str.encode())
    print("Temperature sent to server:", temperature)

    # Receive and print the response from the server
    response = client_socket.recv(1024).decode()
    print(f"Received response: {response}")

  # Enter deep sleep for 30 seconds(30000 milliseconds)
    machine.deepsleep(30000)
    
# Close the socket
client_socket.close()
print("Socket closed")
