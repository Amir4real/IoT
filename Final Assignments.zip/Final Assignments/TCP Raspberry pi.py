
import socket

server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind(('0.0.0.0', 5005))

print("Waiting for a connection")

while True:
    message, client_address = server_socket.recvfrom(1024)
    message = message.decode()
    
    if not message:
        break
    
    print(f"Received message: {message} from {client_address}")
    
    response = "Message received by the server."
    server_socket.sendto(response.encode(), client_address)

server_socket.close()